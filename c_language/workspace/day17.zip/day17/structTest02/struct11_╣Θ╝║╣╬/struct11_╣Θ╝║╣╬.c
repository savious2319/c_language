#include "MyAddress_�鼺��.h"


void main() {

	Address frd[3] = {
		{0},
		{0},
		{0}
	};

	int size = sizeof(frd) / sizeof(frd[0]);
	inputAddress(size, frd);

	printAddress(size, frd);







}